package org.iclass.spring_9jwt;

public enum Role {
    USER, ADMIN,MANAGER
}